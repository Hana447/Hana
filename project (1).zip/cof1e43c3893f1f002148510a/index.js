let num1=0
let num2=0

let scoreHo=document.getElementById("score").textContent=0
let scoreGe=document.getElementById("scor").textContent=0
    
num1=scoreHo
num2=scoreGe
let two1=scoreHo
let two2=scoreGe
let three1=scoreHo
let three2=scoreGe

function add1(){
num1=scoreHo+1
 scoreHo=num1
 console.log(scoreHo)
}

function add2(){

num2=scoreGe+1

 console.log(num2)
scoreGe=num2

}
function addtwo1(){
    // console.log(scoreHo)
two1=scoreHo+2

 console.log(two1)
scoreHo=two1

}
function addtwo2(){

two2=scoreGe+2

 console.log(two2)
scoreGe=two2

}
function addthree1(){
three1=scoreHo+3

 console.log(three1)
scoreHo=three1

}
function addthree2(){

three2=scoreGe+3

 console.log(three2)
scoreGe=three2

}